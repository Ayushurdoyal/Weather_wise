
def get_weather_data(location, days=2):
    if not location:
        return {
            "today": "No location provided",
            "tomorrow": "No location provided"
        }
    mock_data = {
        "melbourne": {
            "today": "cloudy with occasional showers",
            "tomorrow": "sunny with mild winds",
        },
        "sydney": {
            "today": "clear and warm",
            "tomorrow": "chance of evening rain",
        },
        "brisbane": {
            "today": "humid with thunderstorms",
            "tomorrow": "rain expected in the afternoon",
        },
        "perth": {
            "today": "hot and dry",
            "tomorrow": "cooler with a breeze",
        },
        "adelaide": {
            "today": "partly cloudy",
            "tomorrow": "light rain possible",
        },
        "canberra": {
            "today": "windy and chilly",
            "tomorrow": "clear skies",
        },
        "hobart": {
            "today": "cold and rainy",
            "tomorrow": "sunny with clouds later",
        },
        "darwin": {
            "today": "hot and sunny",
            "tomorrow": "humid with scattered clouds",
        },
        "cairns": {
            "today": "rain expected",
            "tomorrow": "stormy conditions",
        },
        "blue mountains": {
            "today": "cool with fog",
            "tomorrow": "chance of snow",
        },
    }
    location = location.lower()
    return mock_data.get(location, {
        "today": "Weather data not found",
        "tomorrow": "Weather data not found"
    })

def parse_weather_question(question):
    question = question.lower()
    parsed = {"location": None, "time": "today", "intent": "general"}

    # Time detection
    if "tomorrow" in question:
        parsed["time"] = "tomorrow"
    elif "next weekend" in question:
        parsed["time"] = "next weekend"
    elif "today" in question:
        parsed["time"] = "today"

    # Location detection (Australian cities)
    cities = ["melbourne", "sydney", "brisbane", "perth", "adelaide", "canberra", "hobart", "darwin", "cairns", "blue mountains"]
    for city in cities:
        if city in question:
            parsed["location"] = city
            break

    # Intent detection
    if "umbrella" in question or "rain" in question or "raining" in question:
        parsed["intent"] = "rain"
    elif "cold" in question or "jacket" in question or "hot" in question:
        parsed["intent"] = "temperature"
    elif "wear" in question or "clothing" in question or "pack" in question or "sandals" in question:
        parsed["intent"] = "clothing"
    elif "snow" in question or "snowstorm" in question:
        parsed["intent"] = "snow"
    elif "picnic" in question or "barbecue" in question:
        parsed["intent"] = "activity"

    return parsed

def generate_weather_response(parsed, weather_data):
    location = parsed.get("location", "your location")
    time = parsed.get("time", "today")
    forecast = weather_data.get(time, "No forecast available")
    return f"Sure! Here's the forecast for {location} {time}: {forecast}. Let me know if you need advice on what to wear!"

def start_weather_advisor():
    print("Welcome to WeatherWise!")
    print("You can ask things like 'Should I take an umbrella tomorrow in Brisbane?' or type 'exit' to quit.")

    while True:
        question = input("\nAsk your weather question: ")
        if question.strip().lower() == "exit":
            print("Goodbye!")
            break

        parsed = parse_weather_question(question)
        location = parsed.get("location")

        if not location:
            print("Sorry, I couldn't determine the location. Try including an Australian city.")
            continue

        weather = get_weather_data(location)
        response = generate_weather_response(parsed, weather)
        print(response)

if __name__ == "__main__":
    start_weather_advisor()
